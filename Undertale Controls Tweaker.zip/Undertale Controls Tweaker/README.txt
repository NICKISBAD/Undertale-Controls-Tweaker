Made by NICKISBAD on github

https://github.com/NICKISBAD

Put the program in your undertale.exe file's Directory and Open it and it'll activate.